<?php

namespace BlueMedia\OnlinePayments\Model;

abstract class AbstractModel
{
    abstract public function validate();
}
