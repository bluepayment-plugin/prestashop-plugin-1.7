DROP TABLE IF EXISTS `_DB_PREFIX_blue_gateway_transfers`;
DROP TABLE IF EXISTS `_DB_PREFIX_blue_gateway_transfers_shop`;
DROP TABLE IF EXISTS `_DB_PREFIX_blue_gateway_channels`;
DROP TABLE IF EXISTS `_DB_PREFIX_blue_gateway_channels_shop`;
DROP TABLE IF EXISTS `_DB_PREFIX_blue_transactions`;
DROP TABLE IF EXISTS `_DB_PREFIX_blue_apc`;
